field.names <- c("Participant", "MktCenter", "CCYYMM", "Symbol", "Immediacy",
                 "Size", "NumCoveredOrds", "ShrsCoveredOrds", "CxldShrsCoveredOrds",
                 "FillShrsCoveredOrds", "AwayShrsCoveredOrds", "Shrs0to9s",
                 "Shrs10to29s", "Shrs30to59s", "Shrs60to299s", "Shrs5to30m",
                 "AvgRealizedSpread", "AvgEffectiveSpread", "ShrsPriceImprove",
                 "ShrWtdPriceImproved", "ShrWtdPriceImproveTime",
                 "ShrsFilledAtQuote", "ShrWtdAtQuoteTime", "ShrsFilledOutsideQuote",
                 "ShrWtdOutsideQuotePriceDiff", "ShrWtdOutsideQuoteTime")

# These give the meaning of coded fields in the report
field.participants <- list(A="Amex", B="BSE", M="CHX", C="CSE", T="NASD",
                           N="NYSE", P="PCX", X="Phlx")
field.sizes <- list("21"="100-499", "22"="500-1999", "23"="2000-4999", "24"="5000+")
field.immediacy <- list("11"="Market", "12"="Marketable limit", "13"="Inside limit",
                        "14"="At-quote limit", "15"="Near-quote limit")
files2grab <- c("M200204.DAT","M200604.DAT","M201004.DAT","M201404.DAT","M201804.DAT")

exdata1 <- read.csv("M200204.DAT", header=FALSE, sep="|")
colnames(exdata1) <- field.names
exdata2 <- read.csv("M200604.DAT", header=FALSE, sep="|")
colnames(exdata2) <- field.names
exdata3 <- read.csv("M201004.DAT", header=FALSE, sep="|")
colnames(exdata3) <- field.names
exdata4 <- read.csv("M201404.DAT", header=FALSE, sep="|")
colnames(exdata4) <- field.names
exdata5 <- read.csv("M201804.DAT", header=FALSE, sep="|")
colnames(exdata5) <- field.names

y<-c(2002-04,2006-04,2010-04,2014-04,2018-04)

exdata10 <-subset(exdata1, !is.na(`AvgRealizedSpread`))
exdata11 <-subset(exdata10, `Size`<22)
exdata12 <-subset(exdata10, `Size`>21&`Size`<23)
exdata13 <-subset(exdata10, `Size`>22&`Size`<24)
exdata14 <-subset(exdata10, `Size`>23&`Size`<25)

exdata20 <-subset(exdata2, !is.na(`AvgRealizedSpread`))
exdata21 <-subset(exdata20, `Size`<22)
exdata22 <-subset(exdata20, `Size`>21&`Size`<23)
exdata23 <-subset(exdata20, `Size`>22&`Size`<24)
exdata24 <-subset(exdata20, `Size`>23&`Size`<25)

exdata30 <-subset(exdata3, !is.na(`AvgRealizedSpread`))
exdata31 <-subset(exdata30, `Size`<22)
exdata32 <-subset(exdata30, `Size`>21&`Size`<23)
exdata33 <-subset(exdata30, `Size`>22&`Size`<24)
exdata34 <-subset(exdata30, `Size`>23&`Size`<25)

exdata40 <-subset(exdata4, !is.na(`AvgRealizedSpread`))
exdata41 <-subset(exdata40, `Size`<22)
exdata42 <-subset(exdata40, `Size`>21&`Size`<23)
exdata43 <-subset(exdata40, `Size`>22&`Size`<24)
exdata44 <-subset(exdata40, `Size`>23&`Size`<25)

exdata50 <-subset(exdata5, !is.na(`AvgRealizedSpread`))
exdata51 <-subset(exdata50, `Size`<22)
exdata52 <-subset(exdata50, `Size`>21&`Size`<23)
exdata53 <-subset(exdata50, `Size`>22&`Size`<24)
exdata54 <-subset(exdata50, `Size`>23&`Size`<25)

x1<-c(mean(exdata11$AvgRealizedSpread),mean(exdata21$AvgRealizedSpread),mean(exdata31$AvgRealizedSpread),mean(exdata41$AvgRealizedSpread),mean(exdata51$AvgRealizedSpread))
plot(y,x1,type="l",ylim = c(-0.05, 0.2),ylab='AvgRealizedSpread',xlab='Year',col=c("red"))
par(new=TRUE)
x2<-c(mean(exdata12$AvgRealizedSpread),mean(exdata22$AvgRealizedSpread),mean(exdata32$AvgRealizedSpread),mean(exdata42$AvgRealizedSpread),mean(exdata52$AvgRealizedSpread))
plot(y,x2,type="l",ylim = c(-0.05, 0.2),ylab='AvgRealizedSpread',xlab='Year',col=c("blue"))
par(new=TRUE)
x3<-c(mean(exdata13$AvgRealizedSpread),mean(exdata23$AvgRealizedSpread),mean(exdata33$AvgRealizedSpread),mean(exdata43$AvgRealizedSpread),mean(exdata53$AvgRealizedSpread))
plot(y,x3,type="l",ylim = c(-0.05, 0.2),ylab='AvgRealizedSpread',xlab='Year',col=c("green"))
par(new=TRUE)
x4<-c(mean(exdata14$AvgRealizedSpread),mean(exdata24$AvgRealizedSpread),mean(exdata34$AvgRealizedSpread),mean(exdata44$AvgRealizedSpread),mean(exdata54$AvgRealizedSpread))
plot(y,x4,type="l",ylim = c(-0.05, 0.2),ylab='AvgRealizedSpread',xlab='Year',col=c("yellow"))
par(new=TRUE)
x5<-c(mean(exdata15$AvgRealizedSpread),mean(exdata25$AvgRealizedSpread),mean(exdata35$AvgRealizedSpread),mean(exdata45$AvgRealizedSpread),mean(exdata55$AvgRealizedSpread))
plot(y,x53,type="l",ylim = c(-0.05, 0.2),ylab='AvgRealizedSpread',xlab='Year',col=c("black"))
par(new=TRUE)
