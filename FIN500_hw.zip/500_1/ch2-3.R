count<-0
for(t in 1:10000){
  r1<- rnorm(1,0,0.04)
  r2<- rnorm(1,0,0.04)
  r3<- rnorm(1,0,0.04)
  r4<- rnorm(1,0,0.04)
  r5<- rnorm(1,0,0.04)
  
  a1<-r1+1
  a2<-r2+1
  a3<-r3+1
  a4<-r4+1
  a5<-r5+1
  
  x<-((a1+a2+a3+a4+a5)/5)
  y<-((a1*a2*a3*a4*a5)^(1/5))
  
  if(x<y){
    count<-count+1
  }
}
print(count/10000)