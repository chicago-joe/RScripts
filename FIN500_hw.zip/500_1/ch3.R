## Dale W.R. Rosenthal, 2018
## You are free to distribute and use this code so long as you attribute
## it to me or cite the text.
## The legal disclaimer in _A Quantitative Primer on Investments with R_
## applies to this code.  Use or distribution without these comment lines
## is forbidden.
install.packages("xts")
install.packages("Quandl")
install.packages("quantmod")
library(xts)
library(Quandl)
library(quantmod)
Quandl.api_key('iVyBuKymy_j_R7Xxze9t')

#fix inocme

FixIn.tickers <- c("CHRIS/MX_CGF1.1", "CHRIS/MX_CGF1.2","CHRIS/MX_CGB1.1","CHRIS/MX_CGB1.2")
FixIn.raw <- Quandl(FixIn.tickers, type="raw")
FixIn.colnames <- c("Date","CGF1.bid","CGF1.ask","CGB1.bid","CGB1.ask")
colnames(FixIn.raw)<- FixIn.colnames

#filter

NewFixIn<-subset(FixIn.raw,`CGF1.bid`>0&`CGF1.ask`>0&`CGB1.bid`>0&`CGB1.ask`>0,
               select= c('Date','CGF1.bid','CGF1.ask','CGB1.bid','CGB1.ask'))

#spread

NewFixIn$CGF1.spread<-NewFixIn$`CGF1.ask`-NewFixIn$`CGF1.bid`
NewFixIn$CGB1.spread<-NewFixIn$`CGB1.ask`-NewFixIn$`CGB1.bid`

#fractional

NewFixIn$CGF1.fracspread<-log(NewFixIn$`CGF1.ask`) - log(NewFixIn$`CGF1.bid`)
NewFixIn$CGB1.fracspread<-log(NewFixIn$`CGB1.ask`) - log(NewFixIn$`CGB1.bid`)
FixIn.new<-NewFixIn[c(1,2,3,6,8,4,5,7,9)]
FixIn.new1<-NewFixIn[c(1,6,8,7,9)]

#commodity

Commo.tickers <- c("LME/PR_CU.1", "LME/PR_CU.2","LME/PR_AL.1","LME/PR_AL.2","LME/PR_TN.1","LME/PR_TN.2")
Commo.raw <- Quandl(Commo.tickers, type="raw")
Commo.colnames <- c("Date","CU.bid", "CU.ask","AL.bid","AL.ask","TN.bid","TN.ask")
colnames(Commo.raw)<- Commo.colnames

#filter

NewCommo<-subset(Commo.raw,`CU.bid`>0&`CU.ask`>0&`AL.bid`>0&`AL.ask`>0&`TN.bid`>0&`TN.ask`>0,
                 select= c('Date','CU.bid','CU.ask','AL.bid' ,'AL.ask','TN.bid','TN.ask'))

#spread

NewCommo$CU1.spread<-NewCommo$`CU.ask`-NewCommo$`CU.bid`
NewCommo$AL1.spread<-NewCommo$`AL.ask`-NewCommo$`AL.bid`
NewCommo$TN1.spread<-NewCommo$`TN.ask`-NewCommo$`TN.bid`

#fractional

NewCommo$CU1.fracspread<-log(NewCommo$`CU.ask`) - log(NewCommo$`CU.bid`)
NewCommo$AL1.fracspread<-log(NewCommo$`AL.ask`) - log(NewCommo$`AL.bid`)
NewCommo$TN1.fracspread<-log(NewCommo$`TN.ask`) - log(NewCommo$`TN.bid`)
Commo.new<-NewCommo[c(1,2,3,8,9,4,5,10,11,6,7,12,13)]
Commo.new1<-NewCommo[c(1,8,11,9,12,10,13)]

#equity indices

EqiIn.tickers <- c("CHRIS/HKEX_HSI1.1", "CHRIS/HKEX_HSI1.2","CHRIS/MX_SXM1.1","CHRIS/MX_SXM1.2")
EqiIn.raw <- Quandl(EqiIn.tickers, type="raw")
EqiIn.colnames <- c("Date","HSI1.bid","HSI1.ask","SXM1.bid","SXM1.ask")
colnames(EqiIn.raw)<- EqiIn.colnames

#filter

NewEqiIn<-subset(EqiIn.raw,`HSI1.bid`>0&`HSI1.ask`>0&`SXM1.bid`>0&`SXM1.ask`>0,
                 select= c('Date','HSI1.bid','HSI1.ask','SXM1.bid','SXM1.ask'))

#spread

NewEqiIn$HSI1.spread<-NewEqiIn$`HSI1.ask`-NewEqiIn$`HSI1.bid`
NewEqiIn$SXM1.spread<-NewEqiIn$`SXM1.ask`-NewEqiIn$`SXM1.bid`

#fractional

NewEqiIn$HSI1.fracspread<-log(NewEqiIn$`HSI1.ask`) - log(NewEqiIn$`HSI1.bid`)
NewEqiIn$SXM1.fracspread<-log(NewEqiIn$`SXM1.ask`) - log(NewEqiIn$`SXM1.bid`)
EqiIn.new<-NewEqiIn[c(1,2,3,6,8,4,5,7,9)]
EqiIn.new1<-NewEqiIn[c(1,6,8,7,9)]

#FX

FX.tickers <- c("BITFINEX/BTCUSD.1", "BITFINEX/BTCUSD.2")
FX.raw <- Quandl(FX.tickers, type="raw")
FX.colnames <- c("Date","BTCtoUSD.bid","BTCtoUSD.ask")
colnames(FX.raw)<- FX.colnames

#filter

NewFX<-subset(FX.raw,`BTCtoUSD.bid`>0&`BTCtoUSD.ask`>0,
                 select= c('Date','BTCtoUSD.bid','BTCtoUSD.ask'))

#spread

NewFX$BTCtoUSD.spread<-NewFX$`BTCtoUSD.ask`-NewFX$`BTCtoUSD.bid`

#fractional

NewFX$BTCtoUSD.fracspread<-log(NewFX$`BTCtoUSD.ask`) - log(NewFX$`BTCtoUSD.bid`)
FX.new<-NewFX[c(1,2,3,4)]
FX.new1<-NewFX[c(1,4,5)]

#Equities

Equit.tickers <- c("FINRA/FNSQ_AMD.1", "FINRA/FNSQ_AMD.2","FINRA/FNSQ_RGR.1","FINRA/FNSQ_RGR.2","FINRA/FNSQ_TSLA.1","FINRA/FNSQ_TSLA.2")
Equit.raw <- Quandl(Equit.tickers, type="raw")
Equit.colnames <- c("Date","AMD.bid", "AMD.ask","RGR.bid","RGR.ask","TSLA.bid","TSLA.ask")
colnames(Equit.raw)<- Equit.colnames

#filter

NewEquit<-subset(Equit.raw,`AMD.bid`>0&`AMD.ask`>0&`RGR.bid`>0&`RGR.ask`>0&`TSLA.bid`>0&`TSLA.ask`>0,
                 select= c('Date','AMD.bid','AMD.ask','RGR.bid' ,'RGR.ask','TSLA.bid','TSLA.ask'))

#spread

NewEquit$AMD.spread<-NewEquit$`AMD.ask`-NewEquit$`AMD.bid`
NewEquit$RGR.spread<-NewEquit$`RGR.ask`-NewEquit$`RGR.bid`
NewEquit$TSLA.spread<-NewEquit$`TSLA.ask`-NewEquit$`TSLA.bid`

#fractional

NewEquit$AMD.fracspread<-log(NewEquit$`AMD.ask`) - log(NewEquit$`AMD.bid`)
NewEquit$RGR.fracspread<-log(NewEquit$`RGR.ask`) - log(NewEquit$`RGR.bid`)
NewEquit$TSLA.fracspread<-log(NewEquit$`TSLA.ask`) - log(NewEquit$`TSLA.bid`)
Equit.new<-NewEquit[c(1,2,3,8,9,4,5,10,11,6,7,12,13)]
Equit.new1<-NewEquit[c(1,8,11,9,12,10,13)]

#summary

temp<-merge(FixIn.new1, Commo.new1,by='Date', all=T)
temp1<-merge(temp, EqiIn.new1,by='Date', all=T)
temp2<-merge(temp1, FX.new1,by='Date', all=T)
temp3<-merge(temp2, Equit.new1,by='Date', all=T)


alldata <- temp2

summary(alldata)

#fix inocme

CGF1.spread<-FixIn.new1[,c(1,2)]
plot(CGF1.spread,type="l")

CGB1.spread<-FixIn.new1[,c(1,4)]
plot(CGB1.spread,type="l")

CGF1.fracspread<-FixIn.new1[,c(1,3)]
plot(CGF1.fracspread,type="l")

CGB1.fracspread<-FixIn.new1[,c(1,5)]
plot(CGB1.fracspread,type="l")

#commodity

CU1.spread<-Commo.new1[,c(1,2)]
plot(CU1.spread,type="l")

AL1.spread<-Commo.new1[,c(1,4)]
plot(AL1.spread,type="l")

TN1.spread<-Commo.new1[,c(1,6)]
plot(TN1.spread,type="l")

CU1.fracspread<-Commo.new1[,c(1,3)]
plot(CU1.fracspread,type="l")

AL1.fracspread<-Commo.new1[,c(1,5)]
plot(AL1.fracspread,type="l")

TN1.fracspread<-Commo.new1[,c(1,7)]
plot(TN1.fracspread,type="l")

#equity indices

HSI1.spread<-EqiIn.new1[,c(1,2)]
plot(HSI1.spread,type="l")

SXM1.spread<-EqiIn.new1[,c(1,4)]
plot(SXM1.spread,type="l")

HSI1.fracspread<-EqiIn.new1[,c(1,3)]
plot(HSI1.fracspread,type="l")

SXM1.fracspread<-EqiIn.new1[,c(1,5)]
plot(SXM1.fracspread,type="l")

#FX

BTCtoUSD.spread<-FX.new1[,c(1,2)]
plot(BTCtoUSD.spread,type="l")

BTCtoUSD.fracspread<-FX.new1[,c(1,3)]
plot(BTCtoUSD.fracspread,type="l")

#Equities

AMD.spread<-Equit.new1[,c(1,2)]
plot(AMD.spread,type="l")

RGR.spread<-Equit.new1[,c(1,4)]
plot(RGR.spread,type="l")

TSLA.spread<-Equit.new1[,c(1,6)]
plot(TSLA.spread,type="l")

AMD.fracspread<-Equit.new1[,c(1,3)]
plot(AMD.fracspread,type="l")

RGR.fracspread<-Equit.new1[,c(1,5)]
plot(RGR.fracspread,type="l")

TSLA.fracspread<-Equit.new1[,c(1,7)]
plot(TSLA.fracspread,type="l")

