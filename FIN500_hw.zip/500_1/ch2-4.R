install.packages("xts")
install.packages("Quandl")
install.packages("quantmod")
install.packages("ggplot2")
library(ggplot2)
library(xts)
library(Quandl)
library(quantmod)
Quandl.api_key('iVyBuKymy_j_R7Xxze9t')

# Equity
shortvol.tickers <- c("FINRA/FNSQ_AMD.1", "FINRA/FNSQ_RGR.1", "FINRA/FNSQ_TSLA.1")  
shortvol.raw <- Quandl(shortvol.tickers, type="xts")
colnames(shortvol.raw) <- c("AMD.shortvol", "RGR.shortvol", "TSLA.shortvol")

eq.tickers <- c("AMD", "RGR", "TSLA")
tmp <- getSymbols(eq.tickers[1], src="yahoo", env=NULL)
adj.col <- last(colnames(tmp))
eq.raw <- tmp[,adj.col]                       
for (j in 2:length(eq.tickers))              
{
  tmp <- getSymbols(eq.tickers[j], src="yahoo", env=NULL)
  adj.col <- last(colnames(tmp))
  eq.raw <- cbind(eq.raw, tmp[,adj.col])
}
mix.raw <- cbind(eq.raw, shortvol.raw)
mix.new <- subset(mix.raw, `AMD.shortvol`>0&`RGR.shortvol`>0&`TSLA.shortvol`>0&`TSLA.Adjusted`>0&`AMD.Adjusted`>0&`RGR.Adjusted`>0,
                  select = c(`AMD.shortvol`,`AMD.Adjusted`,`RGR.shortvol`,`RGR.Adjusted`,`TSLA.shortvol`,`TSLA.Adjusted`))

summary(mix.new)
amd.plot<-log(mix.new[,1])
amd.plot<- cbind(amd.plot,log(mix.new[,2]))
plot(amd.plot)
rgr.plot<-log(mix.new[,3])
rgr.plot<- cbind(rgr.plot,log(mix.new[,4]))
plot(rgr.plot)
tsla.plot<-log(mix.new[,5])
tsla.plot<- cbind(tsla.plot,log(mix.new[,6]))
plot(tsla.plot)

