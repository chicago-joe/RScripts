## Dale W.R. Rosenthal, 2018
## You are free to distribute and use this code so long as you attribute
## it to me or cite the text.
## The legal disclaimer in _A Quantitative Primer on Investments with R_
## applies to this code.  Use or distribution without these comment lines
## is forbidden.
install.packages("xts")
install.packages("Quandl")
install.packages("quantmod")
library(xts)
library(Quandl)
library(quantmod)
Quandl.api_key('iVyBuKymy_j_R7Xxze9t')
# Get constant-maturity (US) Treasuries
ust.tickers <- c("FRED/DGS3MO", "FRED/DGS2", "FRED/DGS10", "FRED/DGS30")
ust.raw <- Quandl(ust.tickers, type="xts")
ust.colnames <- c("UST3M", "UST2Y", "UST10Y", "UST30Y")
colnames(ust.raw) <- ust.colnames

corpbond.raw <- Quandl("FED/RIMLPBAAR_N_B", type="xts")
colnames(corpbond.raw) <- c("USBaaCorp")

re.tickers <- c("CHRIS/CME_JR1", "NLY", "EQR", "CAR-UN.TO")
re.raw <- Quandl(re.tickers[1], type="xts")[,"Settle"]
# Sadly, there is a data error: a few days reported 10x price
re.raw[re.raw>1000] <- re.raw[re.raw>2000]/10

for (j in 2:length(re.tickers)) {
  tmp <- getSymbols(re.tickers[j], src="yahoo", env=NULL)
  adj.col <- last(colnames(tmp))
  re.raw <- cbind(re.raw, tmp[,adj.col])
}
colnames(re.raw) <- c("DJUSRE", "NLY", "EqRes", "CdnApt")

commodities.tickers <- c("CHRIS/CME_GI1", "CHRIS/CME_C1", "CHRIS/CME_S1", "CHRIS/CME_HG1",
                         "CHRIS/SHFE_RB1", "CHRIS/CME_CL1", "CHRIS/CME_NG1")
commodities.raw <- Quandl(commodities.tickers[1], type="xts")[,"Settle"]
for (j in 2:length(commodities.tickers)) {
  tmp <- Quandl(commodities.tickers[j], type="xts")[,"Settle"]
  commodities.raw <- cbind(commodities.raw, tmp)
}
colnames(commodities.raw) <- c("GSCI", "Corn", "Soybeans", "Copper", "Rebar",
                               "WTI", "USNatgas")

eqtidx.tickers <- c("^GSPC", "^RUT", "^GSPTSE", "^MXX", "^FTSE", "^STOXX50E",
                    "^SSMI", "^HSI", "^STI", "^N225")
tmp <- getSymbols(eqtidx.tickers[1], src="yahoo", env=NULL)
adj.col <- last(colnames(tmp))
eqtidx.raw <- tmp[,adj.col]
for (j in 2:length(eqtidx.tickers)) {
  tmp <- getSymbols(eqtidx.tickers[j], src="yahoo", env=NULL)
  adj.col <- last(colnames(tmp))
  eqtidx.raw <- cbind(eqtidx.raw, tmp[,adj.col])
}
colnames(eqtidx.raw) <- c("SP500", "R2000", "TSX", "IPC", "FTSE100", "ESTX50",
                          "SMI", "HangSeng", "STI", "NK225")

fx.tickers <- c("CHRIS/CME_JY1", "CHRIS/CME_EC1", "CHRIS/CME_CD1", "CHRIS/ICE_AR1")
fx.raw <- Quandl(fx.tickers[1], type="xts")[,"Settle"]
for (j in 2:length(fx.tickers)) {
  tmp <- Quandl(fx.tickers[j], type="xts")[,"Settle"]
  fx.raw <- cbind(fx.raw, tmp)
}
colnames(fx.raw) <- c("USDJPY", "USDEUR", "USDCAD", "AUDNZD")

alldata.full <- cbind(ust.raw, corpbond.raw, re.raw, commodities.raw, eqtidx.raw, fx.raw)
alldata <- alldata.full["20140101/20180515"]

summary(alldata)

for (v in colnames(alldata)) {
  plot.tmp <- plot(alldata[,v], main=v)
  print(plot.tmp)
  invisible(readline(prompt="Press [enter] to continue"))
}
newdata<-na.omit(alldata)
temp<-c()
for(i in 1:30){
  sd(newdata[,i])
  temp<-c(temp,sd(newdata[,i]))
}
temp
std.of.each = data.frame(name = c('UST3M','UST2Y','UST10Y','UST30Y','USBaaCorp','DJUSRE','NLY','EqRes','CdnApt','GSCI','Corn','Soybeans','Copper','Rebar','WTI',
                         'USNatgas','SP500','R2000','TSX','IPC','FTSE100','ESTX50','SMI','HangSeng','STI','NK225','USDJPY','USDEUR','USDCAD','AUDNZD'),temp)
std.of.each
