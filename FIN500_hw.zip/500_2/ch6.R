## Dale W.R. Rosenthal, 2018
## You are free to distribute and use this code so long as you attribute
## it to me or cite the text.
## The legal disclaimer in _A Quantitative Primer on Investments with R_
## applies to this code.  Use or distribution without these comment lines
## is forbidden.
library(xts)
library(Quandl)
library(Metrics)
Quandl.api_key('iVyBuKymy_j_R7Xxze9t')

# Grab constant-maturity US Treasuries
ust.tickers <- c("FRED/DGS3MO", "FRED/DGS2", "FRED/DGS5", "FRED/DGS10", "FRED/DGS30")
ust <- Quandl(ust.tickers, type="xts")/100
ust.colnames <- c("T3M", "T2Y", "T5Y", "T10Y", "T30Y")
colnames(ust) <- ust.colnames

# Grab inflation-indexed US Treasuries
tips.yields <- c("TIPSY02", "TIPSY05", "TIPSY10")
tips <- Quandl("FED/TIPSY", type="xts")[,tips.yields]/100

# expected inflation and CPI are only available monthly...
# For expected inflation and CPI, only get the first column of data... like so:
exinfl <- Quandl("FRBC/EXIN", type="xts")[,1]
colnames(exinfl) <- c("EXINFL")
cpi <- Quandl("FRBC/USINFL", type="xts")[,1]
colnames(cpi) <- c("CPI")

# Calculate inflation and surprise by projecting CPI for one year ahead
# The surprise is how much the CPI differed from what was
# projected a year earlier
infl.yoy <- log(cpi) - log(lag(cpi, 12))
colnames(infl.yoy) <- c("INFL.YOY")
infl.mom <- (log(cpi) - log(lag(cpi)))*12
colnames(infl.mom) <- c("INFL.MOM")
excpi <- cpi*(1+exinfl)  # expected CPI in twelve months
cpi.surprise <- log(cpi) - log(lag(excpi, 12))  # % CPI surprise
colnames(cpi.surprise) <- c("INFLSURP")

# combine the data and carry monthly observations forward
inflation.tmp <- cbind(ust, tips, infl.yoy, infl.mom, exinfl, cpi, excpi, cpi.surprise)["1999/"]
inflation.data <- na.locf(inflation.tmp)

# hypothetical inflation 
## risk free rate = CPI + real rate
TWO_YHR_1 <- inflation.data$T2Y-inflation.data$EXINFL
FIVE_YHR_1 <- inflation.data$T5Y-inflation.data$EXINFL
TEN_YHR_1 <- inflation.data$T10Y-inflation.data$EXINFL

HYPO1<-cbind(TWO_YHR_1,FIVE_YHR_1,TEN_YHR_1,inflation.data$TIPSY02,inflation.data$TIPSY05,inflation.data$TIPSY10)
HYPO1<-na.omit(HYPO1)

mse(HYPO1$T2Y, HYPO1$TIPSY02)
mse(HYPO1$T5Y, HYPO1$TIPSY05)
mse(HYPO1$T10Y,HYPO1$TIPSY10)
## end of hypothsis1

## ## risk free rate = CPI + real rate + lambda_two*var(i) (expected inflation)
TWO_YHR_2 <- inflation.data$T2Y-inflation.data$TIPSY02-inflation.data$EXINFL
FIVE_YHR_2 <- inflation.data$T5Y-inflation.data$TIPSY05-inflation.data$EXINFL
TEN_YHR_2 <- inflation.data$T10Y-inflation.data$TIPSY10-inflation.data$EXINFL
TWO_YHR_2<-na.omit(TWO_YHR_2)
FIVE_YHR_2<-na.omit(FIVE_YHR_2)
TEN_YHR_2<-na.omit(TEN_YHR_2)

SURP<-inflation.data$INFLSURP^2

HYPO2<-cbind(TWO_YHR_2,FIVE_YHR_2,TEN_YHR_2,SURP)
HYPO2<-na.omit(HYPO2)
#

lambda_two_02<-lm(formula =T2Y~INFLSURP,data = HYPO2)
lambda_two_02_temp<-lambda_two_02$coefficients
miu_two_02<-lambda_two_02_temp[1]
lambda_two_02_i<-lambda_two_02_temp[2]

lambda_two_05<-lm(formula =T5Y~INFLSURP,data = HYPO2)
lambda_two_05_temp<-lambda_two_05$coefficients
miu_two_05<-lambda_two_05_temp[1]
lambda_two_05_i<-lambda_two_05_temp[2]

lambda_two_10<-lm(formula =T10Y~INFLSURP,data = HYPO2)
lambda_two_10_temp<-lambda_two_10$coefficients
miu_two_10<-lambda_two_10_temp[1]
lambda_two_10_i<-lambda_two_10_temp[2]

mse(HYPO2$T2Y, (miu_two_02+HYPO2$INFLSURP*lambda_two_02_i))
mse(HYPO2$T5Y, (miu_two_05+HYPO2$INFLSURP*lambda_two_05_i))
mse(HYPO2$T10Y, (miu_two_10+HYPO2$INFLSURP*lambda_two_10_i))
## end of hypothsis2

## ## risk free rate = CPI + real rate + lambda_three*inflation surprise
##E(R)-E(r)-E(i) = miu+ lambda_r* var(r) +lambda_i* var(i)+e
##nominal real EXINFL TIPSyield INFLSURP
TWO_YHR_3 <- inflation.data$T2Y-inflation.data$TIPSY02-inflation.data$EXINFL
FIVE_YHR_3 <- inflation.data$T5Y-inflation.data$TIPSY05-inflation.data$EXINFL
TEN_YHR_3 <- inflation.data$T10Y-inflation.data$TIPSY10-inflation.data$EXINFL
TWO_YHR_3<-na.omit(TWO_YHR_3)
FIVE_YHR_3<-na.omit(FIVE_YHR_3)
TEN_YHR_3<-na.omit(TEN_YHR_3)

TIPS_02_diff<-(diff(inflation.data$TIPSY02))^2
TIPS_05_diff<-(diff(inflation.data$TIPSY05))^2
TIPS_10_diff<-(diff(inflation.data$TIPSY10))^2

SURP<-inflation.data$INFLSURP^2

HYPO3<-cbind(TWO_YHR_3,FIVE_YHR_3,TEN_YHR_3,TIPS_02_diff,TIPS_05_diff,TIPS_10_diff,SURP)
HYPO3<-na.omit(HYPO3)

lambda_three_02<-lm(formula =T2Y~TIPSY02+INFLSURP,data = HYPO3)
lambda_three_02_temp<-lambda_three_02$coefficients
miu_three_02<-lambda_three_02_temp[1]
lambda_three_02_r<-lambda_three_02_temp[2]
lambda_three_02_i<-lambda_three_02_temp[3]

lambda_three_05<-lm(formula =T5Y~TIPSY05+INFLSURP,data = HYPO3)
lambda_three_05_temp<-lambda_three_05$coefficients
miu_three_05<-lambda_three_05_temp[1]
lambda_three_05_r<-lambda_three_05_temp[2]
lambda_three_05_i<-lambda_three_05_temp[3]

lambda_three_10<-lm(formula =T10Y~TIPSY10+INFLSURP,data = HYPO3)
lambda_three_10_temp<-lambda_three_10$coefficients
miu_three_10<-lambda_three_10_temp[1]
lambda_three_10_r<-lambda_three_10_temp[2]
lambda_three_10_i<-lambda_three_10_temp[3]

mse(HYPO3$T2Y, (miu_three_02+HYPO3$TIPSY02*lambda_three_02_r+HYPO3$INFLSURP*lambda_three_02_i))
mse(HYPO3$T5Y, (miu_three_05+HYPO3$TIPSY05*lambda_three_05_r+HYPO3$INFLSURP*lambda_three_05_i))
mse(HYPO3$T10Y, (miu_three_10+HYPO3$TIPSY10*lambda_three_10_r+HYPO3$INFLSURP*lambda_three_10_i))
## end of hypothsis3

# reversing the model(need review*****)
SURP<-inflation.data$INFLSURP^2
TIPS_10_diff<-(diff(inflation.data$TIPSY10))^2
HYPO_reversing<-cbind(inflation.data$T10Y,inflation.data$TIPSY10,inflation.data$EXINFL,TIPS_10_diff,SURP)
HYPO_reversing<-na.omit(HYPO_reversing)
colnames(HYPO_reversing)<-c("T10Y","TIPS10Y","EXINFL","VARr","INFLSURP")
HYPO_reversing<-na.omit(HYPO_reversing)
lambda_re<-lm(formula =INFLSURP~T10Y+TIPS10Y+EXINFL+VARr,data = HYPO_reversing)
                            
lambda_re_temp<-lambda_re$coefficients
miu_re<-lambda_re_temp[1]
lambda_re_T10Y<-lambda_re_temp[2]
lambda_re_TIPS10Y<-lambda_re_temp[3]
lambda_re_EXINFL<-lambda_re_temp[4]
lambda_re_VARr<-lambda_re_temp[5]

mse(HYPO_reversing$INFLSURP, (miu_re+HYPO_reversing$T10Y*lambda_re_T10Y+HYPO_reversing$TIPS10Y*lambda_re_TIPS10Y+HYPO_reversing$EXINFL*lambda_re_EXINFL+HYPO_reversing$VARr*lambda_re_VARr))

# backward Hodrick-Prescott filter function(done)
hpbackfilter <- function(y, lambda) {
  n <- length(y)
  I <- diag(1, nrow = n)
  # build the curvature matrix
  K <- matrix(0, nrow=n-2, ncol=n)
  for (i in 1:(n-2)) {
    K[i,i:(i+2)] = c(1,-2,1)
  }
  # now invert and multiply by the data
  hat.matrix <- solve(I+2*lambda*t(K)%*%K)
  hat.matrix %*% y
}
lambda.monthly <- 129600 # for monthly data
tau <- hpbackfilter(cpi, lambda.monthly)
inflation_plot<-cpi
inflation_plot<-cbind(inflation_plot,tau)
colnames(inflation_plot) <- c("CPI","tau")
inflation_plot<-na.omit(inflation_plot)
# plot
plot(inflation_plot,col=c("red","blue"),ylab="CPI",xlab="Year",lwd=2,main="tau-CPI")
inflation_plot_log<-log(inflation_plot)
plot(inflation_plot_log,col=c("red","blue"),ylab="CPI",xlab="Year",lwd=2,main="tau-CPI(log)")
mean(inflation_plot$tau-inflation_plot$CPI)
# MSE
mse(inflation_plot$CPI, inflation_plot$tau)

# end

