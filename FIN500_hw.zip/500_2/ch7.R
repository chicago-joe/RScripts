## Dale W.R. Rosenthal, 2018
## You are free to distribute and use this code so long as you attribute
## it to me or cite the text.
## The legal disclaimer in _A Quantitative Primer on Investments with R_
## applies to this code.  Use or distribution without these comment lines
## is forbidden.
library(Quandl)
library(xts)
library(quantmod)
library(PerformanceAnalytics)
Quandl.api_key('iVyBuKymy_j_R7Xxze9t')
                                                                                                                                                                                                                                                                                                                                                                      
# Example of reading in CMTs from Quandl
# Name columns so we know what each holds after joining them together
ust.tickers <- c("FRED/DGS3MO", "FRED/DGS2", "FRED/DGS10", "FRED/DGS30")
ust.raw <- Quandl(ust.tickers, type="xts")/100
colnames(ust.raw) <- c("T3M.yld", "T2Y.yld", "T10Y.yld", "T30Y.yld")

# This is a way to get approximate returns for these bonds.
# Later on, you will learn about duration and why we can do this. 
ust.yieldchanges <- diff(ust.raw)
colnames(ust.yieldchanges) <- c("T3M", "T2Y", "T10Y", "T30Y")
ust <- ust.yieldchanges
ust$T3M  <- -0.25*ust.yieldchanges$T3M
ust$T2Y  <- -1.98*ust.yieldchanges$T2Y
ust$T10Y <- -8.72*ust.yieldchanges$T10Y
ust$T30Y <- -19.2*ust.yieldchanges$T30Y

# Get Eurodollar futures (settlement) prices and create log-returns.
ed1.raw <- Quandl("CHRIS/CME_ED1", type="xts")[,"Settle"]
ed1 <- diff(log(ed1.raw))
colnames(ed1) <- c("ED1")
ed24.raw <- Quandl("CHRIS/CME_ED8", type="xts")[,"Settle"]
ed24 <- diff(log(ed24.raw))
colnames(ed24) <- c("ED8")

# Get S&P 500 prices (just adjusted close); then create log-returns.
# Do similarly for the Russell 2000, and other stocks.
adj.close <- 6  # 6th field is adjusted close
spx.raw <- getSymbols("^GSPC", source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
colnames(spx.raw) <- c("SPX.prc")
spx <- diff(log(spx.raw))
colnames(spx) <- c("SPX")

#Russell 2000
rut.raw <- getSymbols("^RUT", source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
colnames(rut.raw) <- c("RUT.prc")
rut <- diff(log(rut.raw))
colnames(rut) <- c("RUT")

#Group1 and group2
eq.tickers<-c("PG","XOM","IBM","MMM","KO","GS","AXP","WMT","MRK","DIS","HD","AAPL","CARB","CBRE",
                "CZR","F","FBC","IMGN","IRDM","SBUX","SVU","SYMC","UPS","VLO")
yourticker.raw <- getSymbols(eq.tickers[1], source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
for(i in 2:length(eq.tickers))
{
eq.temp <- getSymbols(eq.tickers[i], source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
yourticker.raw<-merge(yourticker.raw, eq.temp, all=T)
}
colnames(yourticker.raw) <- c("PG.prc","XOM.prc","IBM.prc","MMM.prc","KO.prc","GS.prc","AXP.prc","WMT.prc","MRK.prc","DIS.prc"
                              ,"HD.prc","AAPL.prc","CARB.prc","CBRE.prc",
                              "CZR.prc","F.prc","FBC.prc","IMGN.prc","IRDM.prc","SBUX.prc","SVU.prc","SYMC.prc","UPS.prc","VLO.prc")
yourticker <- diff(log(yourticker.raw))
colnames(yourticker) <- c("PG","XOM","IBM","MMM","KO","GS","AXP","WMT","MRK","DIS","HD","AAPL","CARB","CBRE",
                          "CZR","F","FBC","IMGN","IRDM","SBUX","SVU","SYMC","UPS","VLO")
# Join all of the datasets together: US Treasuries, Eurodollars,
# S&P 500, Russell 2000, and group 1 and group 2 stocks.
# Then trim them down so the dates are consistent.
alldata.full <- cbind(ust.raw, ust, ed1,ed1.raw, ed24, spx.raw, spx,
                      rut.raw, rut, yourticker.raw, yourticker)
alldata <- alldata.full["20141001/20181001"]

# Calculate annual volatilities like so:
apply(alldata, 2, sd,na.rm=TRUE)*sqrt(250)

# skewness and kurtosis are independent of time; no need to scale them
skewness(alldata, method="moment")
kurtosis(alldata, method="moment")

##1 Risk-Free Price Risk
#a) average yield
paste("(T3M.yld)mean=",mean(alldata$T3M.yld,na.rm=TRUE))
paste("(T2Y.yld)mean=",mean(alldata$T2Y.yld,na.rm=TRUE))
paste("(T10Y.yld)mean=",mean(alldata$T10Y.yld,na.rm=TRUE))
paste("(T30Y.yld)mean=",mean(alldata$T30Y.yld,na.rm=TRUE))

#b) average log-returns
paste("(T3M.log-returns)mean=",mean(alldata$T3M,na.rm=TRUE))
paste("(T2Y.log-returns)mean=",mean(alldata$T2Y,na.rm=TRUE))
paste("(T10Y.log-returns)mean=",mean(alldata$T10Y,na.rm=TRUE))
paste("(T30Y.log-returns)mean=",mean(alldata$T30Y,na.rm=TRUE))

#c) annualized std of log-returns
paste("(T3M.log-returns)std_annualized=",sqrt(250)*sd(alldata$T3M,na.rm=TRUE))
paste("(T2Y.log-returns)std_annualized=",sqrt(250)*sd(alldata$T2Y,na.rm=TRUE))
paste("(T10Y.log-returns)std_annualized=",sqrt(250)*sd(alldata$T10Y,na.rm=TRUE))
paste("(T30Y.log-returns)std_annualized=",sqrt(250)*sd(alldata$T30Y,na.rm=TRUE))

#d) skewness & kurtosis
paste("(T3M.log-returns)skewness=",skewness(alldata$T3M,na.rm=TRUE, method="moment"))
paste("(T3M.log-returns)kurtosis=",kurtosis(alldata$T3M,na.rm=TRUE, method="moment"))

paste("(T2Y.log-returns)skewness=",skewness(alldata$T2Y,na.rm=TRUE, method="moment"))
paste("(T2Y.log-returns)kurtosis=",kurtosis(alldata$T2Y,na.rm=TRUE, method="moment"))

paste("(T10Y.log-returns)skewness=",skewness(alldata$T10Y,na.rm=TRUE, method="moment"))
paste("(T10Y.log-returns)kurtosis=",kurtosis(alldata$T10Y,na.rm=TRUE, method="moment"))

paste("(T30Y.log-returns)skewness=",skewness(alldata$T30Y,na.rm=TRUE, method="moment"))
paste("(T30Y.log-returns)kurtosis=",kurtosis(alldata$T30Y,na.rm=TRUE, method="moment"))

##2 Short-term Credit and Price Risk
#a) std of log-returns
paste("(ED1.log-returns)std_annualized=",sqrt(250)*sd(alldata$ED1,na.rm=TRUE))
paste("(ED8.log-returns)std_annualized=",sqrt(250)*sd(alldata$ED8,na.rm=TRUE))

#b) skewness & kurtosis
paste("(ED1.log-returns)skewness=",skewness(alldata$ED1,na.rm=TRUE, method="moment"))
paste("(ED1.log-returns)kurtosis=",kurtosis(alldata$ED1,na.rm=TRUE, method="moment"))

paste("(ED8.log-returns)skewness=",skewness(alldata$ED8,na.rm=TRUE, method="moment"))
paste("(ED8.log-returns)kurtosis=",kurtosis(alldata$ED8,na.rm=TRUE, method="moment"))

#c) Eurodollars vs CMTs
skewness(alldata$T3M,na.rm=TRUE, method="moment")
kurtosis(alldata$T3M,na.rm=TRUE, method="moment")

skewness(alldata$T2Y,na.rm=TRUE, method="moment")
kurtosis(alldata$T2Y,na.rm=TRUE, method="moment")

skewness(alldata$ED1,na.rm=TRUE, method="moment")
kurtosis(alldata$ED1,na.rm=TRUE, method="moment")

skewness(alldata$ED8,na.rm=TRUE, method="moment")
kurtosis(alldata$ED8,na.rm=TRUE, method="moment")

#d) TED spread
ED.yld<-alldata$T3M
ED.yld$T3M<-((100-alldata$Settle)/100)
colnames(ED.yld)<-c("ed.yld")
TED.spread<-ED.yld$ed.yld-alldata$T3M.yld
TED.spread.bp<-TED.spread*10000
colnames(TED.spread.bp)<-c("TED.bp")
paste("(TED)mean=",mean(TED.spread.bp$TED.bp,na.rm=TRUE))
paste("(TED)std=",sd(TED.spread.bp$TED.bp,na.rm=TRUE))
plot(TED.spread.bp,col=c("black"),ylab="CPI",xlab="Year",lwd=1,main="TED spread")

##3 Equity Price Risk
#a) average price
paste("(SPX)mean=",mean(alldata$SPX.prc,na.rm=TRUE))
paste("(RUT)mean=",mean(alldata$RUT.prc,na.rm=TRUE))
stocks_G1.raw<-alldata[,c(16:26)]
stocks_G1.raw<-na.omit(stocks_G1.raw)
stocks_G1.raw.temp<-stocks_G1.raw[1,]
stocks_G1<-stocks_G1.raw[,1]
stocks_G1.raw<-sweep(stocks_G1.raw,2,stocks_G1.raw.temp,'/')
stocks_G1[,1]<-apply(stocks_G1.raw,1,sum)
stocks_G1<-na.omit(stocks_G1)
colnames(stocks_G1) <- c("Index.Price.G1")
mean(stocks_G1)

stocks_G2.raw<-alldata[,c(27:39)]
stocks_G2.raw<-na.omit(stocks_G2.raw)
stocks_G2.raw.temp<-stocks_G2.raw[1,]
stocks_G2<-stocks_G2.raw[,1]
stocks_G2.raw<-sweep(stocks_G2.raw,2,stocks_G2.raw.temp,'/')
stocks_G2[,1]<-apply(stocks_G2.raw,1,sum)
stocks_G2<-na.omit(stocks_G2)
colnames(stocks_G2) <- c("Index.Price.G2")
mean(stocks_G2)

#b) average daily log-returns
paste("(SPX.log-returns)mean=",mean(alldata$SPX,na.rm=TRUE))
paste("(RUT.log-returns)mean=",mean(alldata$RUT,na.rm=TRUE))
stocks_G1_log <- diff(log(stocks_G1))
colnames(stocks_G1_log) <- c("Index.Price.G1.Log")
stocks_G1_log<-na.omit(stocks_G1_log)
mean(stocks_G1_log)

stocks_G2_log <- diff(log(stocks_G2))
colnames(stocks_G2_log) <- c("Index.Price.G2.Log")
stocks_G2_log<-na.omit(stocks_G2_log)
mean(stocks_G2_log)

#c) annualized mean of log-returns
paste("(SPX.log-returns)mean_annualized=",250*mean(alldata$SPX,na.rm=TRUE))
paste("(RUT.log-returns)mean_annualized=",250*mean(alldata$RUT,na.rm=TRUE))
paste("(G1.log-returns)mean_annualized=",250*mean(stocks_G1_log))
paste("(G2.log-returns)mean_annualized=",250*mean(stocks_G2_log))
mean(cbind(mean(alldata$T3M.yld,na.rm=TRUE)
           ,mean(alldata$T2Y.yld,na.rm=TRUE)
           ,mean(alldata$T10Y.yld,na.rm=TRUE)
           ,mean(alldata$T30Y.yld,na.rm=TRUE)))
mean(cbind(mean(alldata$T3M,na.rm=TRUE)
           ,mean(alldata$T2Y,na.rm=TRUE)
           ,mean(alldata$T10Y,na.rm=TRUE)
           ,mean(alldata$T30Y,na.rm=TRUE)))


#d) annualized std of log-returns
paste("(SPX.log-returns)std_annualized=",sqrt(250)*sd(alldata$SPX,na.rm=TRUE))
paste("(RUT.log-returns)std_annualized=",sqrt(250)*sd(alldata$RUT,na.rm=TRUE))
paste("(G1.log-returns)std_annualized=",sqrt(250)*sd(stocks_G1_log))
paste("(G2.log-returns)std_annualized=",sqrt(250)*sd(stocks_G2_log))

#e) skewness & kurtosis
paste("(SPX.log-returns)skewness=",skewness(alldata$SPX,na.rm=TRUE, method="moment"))
paste("(SPX.log-returns)kurtosis=",kurtosis(alldata$SPX,na.rm=TRUE, method="moment"))

paste("(RUT.log-returns)skewness=",skewness(alldata$RUT,na.rm=TRUE, method="moment"))
paste("(RUT.log-returns)kurtosis=",kurtosis(alldata$RUT,na.rm=TRUE, method="moment"))

paste("(G1.log-returns)skewness=",skewness(stocks_G1_log$Index.Price.G1.Log,na.rm=TRUE, method="moment"))
paste("(G1.log-returns)kurtosis=",kurtosis(stocks_G1_log$Index.Price.G1.Log,na.rm=TRUE, method="moment"))

paste("(G2.log-returns)skewness=",skewness(stocks_G2_log$Index.Price.G2.Log,na.rm=TRUE, method="moment"))
paste("(G2.log-returns)kurtosis=",kurtosis(stocks_G2_log$Index.Price.G2.Log,na.rm=TRUE, method="moment"))

##4 Commodity Price Risk
# Get Data
commodities.tickers <- c("CHRIS/CME_CL1", "CHRIS/CME_NG1","CHRIS/CME_HG1","CHRIS/CME_C1")
commodities.raw <- Quandl(commodities.tickers[1], type="xts")[,adj.close]
for (j in 2:length(commodities.tickers)) {
  tmp <- Quandl(commodities.tickers[j], type="xts")[,adj.close]
  commodities.raw <- cbind(commodities.raw, tmp)
}
colnames(commodities.raw) <- c("crude_oil.prc", "natural_gas.prc","copper.prc","corn.prc")
commodities <- diff(log(commodities.raw))
colnames(commodities) <- c("crude_oil", "natural_gas","copper","corn")
comdata.full <- cbind(commodities.raw, commodities)
comdata <- comdata.full["20141001/20181001"]

#a) average price
paste("(crude_oil)mean=",mean(comdata$crude_oil.prc,na.rm=TRUE))
paste("(natural_gas)mean=",mean(comdata$natural_gas.prc,na.rm=TRUE))
paste("(copper)mean=",mean(comdata$copper.prc,na.rm=TRUE))
paste("(corn)mean=",mean(comdata$corn.prc,na.rm=TRUE))

#b) average log-returns
paste("(crude_oil.log-returns)mean=",mean(comdata$crude_oil,na.rm=TRUE))
paste("(natural_gas.log-returns)mean=",mean(comdata$natural_gas,na.rm=TRUE))
paste("(copper.log-returns)mean=",mean(comdata$copper,na.rm=TRUE))
paste("(corn.log-returns)mean=",mean(comdata$corn,na.rm=TRUE)) 

#c) annualized mean of log-returns
paste("(crude_oil.log-returns)mean_annualized=",250*mean(comdata$crude_oil,na.rm=TRUE))
paste("(natural_gas.log-returns)mean_annualized=",250*mean(comdata$natural_gas,na.rm=TRUE))
paste("(copper.log-returns)mean_annualized=",250*mean(comdata$copper,na.rm=TRUE))
paste("(corn.log-returns)mean_annualized=",250*mean(comdata$corn,na.rm=TRUE))

#d) annualized std of log-returns
paste("(crude_oil.log-returns)std_annualized=",sqrt(250)*sd(comdata$crude_oil,na.rm=TRUE))
paste("(natural_gas.log-returns)std_annualized=",sqrt(250)*sd(comdata$natural_gas,na.rm=TRUE))
paste("(copper.log-returns)std_annualized=",sqrt(250)*sd(comdata$copper,na.rm=TRUE))
paste("(corn.log-returns)std_annualized=",sqrt(250)*sd(comdata$corn,na.rm=TRUE))

#e) skewness & kurtosis
paste("(crude_oil.log-returns)skewness=",skewness(comdata$crude_oil,na.rm=TRUE, method="moment"))
paste("(crude_oil.log-returns)kurtosis=",kurtosis(comdata$crude_oil,na.rm=TRUE, method="moment"))

paste("(natural_gas.log-returns)skewness=",skewness(comdata$natural_gas,na.rm=TRUE, method="moment"))
paste("(natural_gas.log-returns)kurtosis=",kurtosis(comdata$natural_gas,na.rm=TRUE, method="moment"))

paste("(copper.log-returns)skewness=",skewness(comdata$copper,na.rm=TRUE, method="moment"))
paste("(copper.log-returns)kurtosis=",kurtosis(comdata$copper,na.rm=TRUE, method="moment"))

paste("(corn.log-returns)skewness=",skewness(comdata$corn,na.rm=TRUE, method="moment"))
paste("(corn.log-returns)kurtosis=",kurtosis(comdata$corn,na.rm=TRUE, method="moment"))

##5 Correlation Heat Map
## use some code from on-line source:
## http://www.sthda.com/english/wiki/ggplot2-quick-correlation-matrix-heatmap-r-software-and-data-visualization
cordata<-cbind(alldata$T3M,alldata$T2Y,alldata$T10Y,alldata$T30Y,alldata$ED1,alldata$ED8,alldata$SPX,alldata$RUT,
               stocks_G1_log,stocks_G2_log,comdata$crude_oil,comdata$natural_gas,comdata$copper,comdata$corn)
cordata<-na.omit(cordata)
colnames(cordata) <- c("T3M","T2Y","T10Y","T30Y","ED1","ED8","SPX","RUT","G1","G2","CrudeOil","NaturalGas","Copper","Corn")
# Cor Matrix
cormat <- round(cor(cordata),2)
head(cormat) 
# Get Upper Cor Matrix
get_upper_tri <- function(cormat){
  cormat[lower.tri(cormat)]<- NA
  return(cormat)
}

upper_tri <- get_upper_tri(cormat)
upper_tri

# Melt the Correlation Matrix
library(reshape2)
melted_cormat <- melt(upper_tri, na.rm = TRUE)
# Heatmap
library(ggplot2)
ggplot(data = melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", 
                       name="Pearson\nCorrelation") +
  theme_minimal()+ 
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1))+
  coord_fixed()
reorder_cormat <- function(cormat){
# Use correlation between variables as distance
  dd <- as.dist((1-cormat)/2)
  hc <- hclust(dd)
  cormat <-cormat[hc$order, hc$order]
}

# Reorder the correlation matrix
cormat <- reorder_cormat(cormat)
upper_tri <- get_upper_tri(cormat)
# Melt the correlation matrix
melted_cormat <- melt(upper_tri, na.rm = TRUE)
# Create a ggheatmap
ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", 
                       name="Pearson\nCorrelation") +
  theme_minimal()+ # minimal theme
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1))+
  coord_fixed()
# Print the heatmap
print(ggheatmap)

ggheatmap + 
  geom_text(aes(Var2, Var1, label = value), color = "black", size = 3) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
    axis.ticks = element_blank(),
    legend.justification = c(1, 0),
    legend.position = c(0.6, 0.7),
    legend.direction = "horizontal")+
  guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                               title.position = "top", title.hjust = 0.5))
