## Dale W.R. Rosenthal, 2018
## You are free to distribute and use this code so long as you attribute
## it to me or cite the text.
## The legal disclaimer in _A Quantitative Primer on Investments with R_
## applies to this code.  Use or distribution without these comment lines
## is forbidden.
library(Quandl)
library(xts)
library(quantmod)
library(PerformanceAnalytics)
Quandl.api_key('iVyBuKymy_j_R7Xxze9t')

# Example of reading in CMTs from Quandl
# Name columns so we know what each holds after joining them together
ust.tickers <- c("FRED/DGS3MO", "FRED/DGS2", "FRED/DGS10", "FRED/DGS30")
ust.raw <- Quandl(ust.tickers, type="xts")/100
colnames(ust.raw) <- c("T3M.yld", "T2Y.yld", "T10Y.yld", "T30Y.yld")

# This is a way to get approximate returns for these bonds.
# Later on, you will learn about duration and why we can do this. 
ust.yieldchanges <- diff(ust.raw)
colnames(ust.yieldchanges) <- c("T3M", "T2Y", "T10Y", "T30Y")
ust <- ust.yieldchanges
ust$T3M  <- -0.25*ust.yieldchanges$T3M
ust$T2Y  <- -1.98*ust.yieldchanges$T2Y
ust$T10Y <- -8.72*ust.yieldchanges$T10Y
ust$T30Y <- -19.2*ust.yieldchanges$T30Y

# Get Eurodollar futures (settlement) prices and create log-returns.
ed1.raw <- Quandl("CHRIS/CME_ED1", type="xts")[,"Settle"]
ed1 <- diff(log(ed1.raw))
colnames(ed1) <- c("ED1")
ed24.raw <- Quandl("CHRIS/CME_ED8", type="xts")[,"Settle"]
ed24 <- diff(log(ed24.raw))
colnames(ed24) <- c("ED8")

# Get S&P 500 prices (just adjusted close); then create log-returns.
# Do similarly for the Russell 2000, and other stocks.
adj.close <- 6  # 6th field is adjusted close
spx.raw <- getSymbols("^GSPC", source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
colnames(spx.raw) <- c("SPX.prc")
spx <- diff(log(spx.raw))
colnames(spx) <- c("SPX")

#Russell 2000
rut.raw <- getSymbols("^RUT", source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
colnames(rut.raw) <- c("RUT.prc")
rut <- diff(log(rut.raw))
colnames(rut) <- c("RUT")

#Group1 and group2
eq.tickers<-c("PG","XOM","IBM","MMM","KO","GS","AXP","WMT","MRK","DIS","HD","AAPL","CARB","CBRE",
              "CZR","F","FBC","IMGN","IRDM","SBUX","SVU","SYMC","UPS","VLO")
yourticker.raw <- getSymbols(eq.tickers[1], source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
for(i in 2:length(eq.tickers))
{
  eq.temp <- getSymbols(eq.tickers[i], source="yahoo", auto.assign=FALSE, return.class="xts")[,adj.close]
  yourticker.raw<-merge(yourticker.raw, eq.temp, all=T)
}
colnames(yourticker.raw) <- c("PG.prc","XOM.prc","IBM.prc","MMM.prc","KO.prc","GS.prc","AXP.prc","WMT.prc","MRK.prc","DIS.prc"
                              ,"HD.prc","AAPL.prc","CARB.prc","CBRE.prc",
                              "CZR.prc","F.prc","FBC.prc","IMGN.prc","IRDM.prc","SBUX.prc","SVU.prc","SYMC.prc","UPS.prc","VLO.prc")
yourticker <- diff(log(yourticker.raw))
colnames(yourticker) <- c("PG","XOM","IBM","MMM","KO","GS","AXP","WMT","MRK","DIS","HD","AAPL","CARB","CBRE",
                          "CZR","F","FBC","IMGN","IRDM","SBUX","SVU","SYMC","UPS","VLO")
commodities.tickers <- c("CHRIS/CME_CL1", "CHRIS/CME_NG1","CHRIS/CME_HG1","CHRIS/CME_C1")
commodities.raw <- Quandl(commodities.tickers[1], type="xts")[,adj.close]
for (j in 2:length(commodities.tickers)) {
  tmp <- Quandl(commodities.tickers[j], type="xts")[,adj.close]
  commodities.raw <- cbind(commodities.raw, tmp)
}
colnames(commodities.raw) <- c("crude_oil.prc", "natural_gas.prc","copper.prc","corn.prc")
commodities <- diff(log(commodities.raw))
colnames(commodities) <- c("crude_oil", "natural_gas","copper","corn")

# Join all of the datasets together: US Treasuries, Eurodollars,
# S&P 500, Russell 2000, and group 1 and group 2 stocks.
# Then trim them down so the dates are consistent.
alldata.full <- cbind(ust.raw, ust, ed1,ed1.raw, ed24, spx.raw, spx,
                      rut.raw, rut, yourticker.raw, yourticker,commodities.raw, commodities)
alldata.full<-na.omit(alldata.full)
alldata <- alldata.full["20141001/20181001"]

# Calculate annual volatilities like so:
apply(alldata, 2, sd)*sqrt(250)

# skewness and kurtosis are independent of time; no need to scale them
skewness(alldata, method="moment")
kurtosis(alldata, method="moment")

##1 SemiDeviation and Expected Shortfall
#a) CMTs
paste("(T3M.log-returns)SemiDeviation=",SemiDeviation(alldata$T3M))
paste("(T2Y.log-returns)SemiDeviation=",SemiDeviation(alldata$T2Y))
paste("(T10Y.log-returns)SemiDeviation=",SemiDeviation(alldata$T10Y))
paste("(T30Y.log-returns)SemiDeviation=",SemiDeviation(alldata$T30Y))

#b) Eurodollar
paste("(ED1.log-returns)SemiDeviation=",SemiDeviation(alldata$ED1))
paste("(ED8.log-returns)SemiDeviation=",SemiDeviation(alldata$ED8))

#c) Equity Indices
stocks_G1.raw<-alldata[,c(16:26)]
stocks_G1.raw<-na.omit(stocks_G1.raw)
stocks_G1.raw.temp<-stocks_G1.raw[1,]
stocks_G1<-stocks_G1.raw[,1]
stocks_G1.raw<-sweep(stocks_G1.raw,2,stocks_G1.raw.temp,'/')
stocks_G1[,1]<-apply(stocks_G1.raw,1,sum)
stocks_G1<-na.omit(stocks_G1)
colnames(stocks_G1) <- c("Index.Price.G1")

stocks_G2.raw<-alldata[,c(27:39)]
stocks_G2.raw<-na.omit(stocks_G2.raw)
stocks_G2.raw.temp<-stocks_G2.raw[1,]
stocks_G2<-stocks_G2.raw[,1]
stocks_G2.raw<-sweep(stocks_G2.raw,2,stocks_G2.raw.temp,'/')
stocks_G2[,1]<-apply(stocks_G2.raw,1,sum)
stocks_G2<-na.omit(stocks_G2)
colnames(stocks_G2) <- c("Index.Price.G2")

stocks_G1_log <- diff(log(stocks_G1))
colnames(stocks_G1_log) <- c("Index.Price.G1.Log")
stocks_G1_log<-na.omit(stocks_G1_log)

stocks_G2_log <- diff(log(stocks_G2))
colnames(stocks_G2_log) <- c("Index.Price.G2.Log")
stocks_G2_log<-na.omit(stocks_G2_log)

paste("(G1.log-returns)SemiDeviation=",SemiDeviation(stocks_G1_log))
paste("(G2.log-returns)SemiDeviation=",SemiDeviation(stocks_G2_log))
paste("(SPX.log-returns)SemiDeviation=",SemiDeviation(alldata$SPX))
paste("(RUT.log-returns)SemiDeviation=",SemiDeviation(alldata$RUT))

#d) Commodity
paste("(crude_oil.log-returns)SemiDeviation=",SemiDeviation(alldata$crude_oil))
paste("(natural_gas.log-returns)SemiDeviation=",SemiDeviation(alldata$natural_gas))
paste("(copper.log-returns)SemiDeviation=",SemiDeviation(alldata$copper))
paste("(corn.log-returns)SemiDeviation=",SemiDeviation(alldata$corn)) 

#e) Expected Shortfall(modified)
#e-1) CMTs
paste("(T3M.log-returns)Expected Shortfall=",ES(alldata$T3M, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

paste("(T2Y.log-returns)Expected Shortfall=",ES(alldata$T2Y, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

paste("(T10Y.log-returns)Expected Shortfall=",ES(alldata$T10Y, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

paste("(T30Y.log-returns)Expected Shortfall=",ES(alldata$T30Y, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

#e-2) Eurodollar
paste("(ED1.log-returns)Expected Shortfall=",ES(alldata$ED1, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(ED8.log-returns)Expected Shortfall=",ES(alldata$ED8, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

#e-3) Equity Indices
paste("(SPX.log-returns)Expected Shortfall=",ES(alldata$SPX, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(RUT.log-returns)Expected Shortfall=",ES(alldata$RUT, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(G1.log-returns)Expected Shortfall=",ES(stocks_G1_log, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(G2.log-returns)Expected Shortfall=",ES(stocks_G2_log, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))


#e-4) Commodity
paste("(crude_oil.log-returns)Expected Shortfall=",ES(alldata$crude_oil, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(natural_gas.log-returns)Expected Shortfall=",ES(alldata$natural_gas, p = 0.99, method = c("modified"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(copper.log-returns)Expected Shortfall=",ES(alldata$copper, p = 0.99, method = c("modified"), clean = c("none"), 
                                               portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                               m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(corn.log-returns)Expected Shortfall=",ES(alldata$corn, p = 0.99, method = c("modified"), clean = c("none"), 
                                               portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                               m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

#e) Expected Shortfall(historical)
#e-1) CMTs
paste("(T3M.log-returns)Expected Shortfall=",ES(alldata$T3M, p = 0.99, method = c("historical"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

paste("(T2Y.log-returns)Expected Shortfall=",ES(alldata$T2Y, p = 0.99, method = c("historical"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

paste("(T10Y.log-returns)Expected Shortfall=",ES(alldata$T10Y, p = 0.99, method = c("historical"), clean = c("none"), 
                                                 portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                 m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

paste("(T30Y.log-returns)Expected Shortfall=",ES(alldata$T30Y, p = 0.99, method = c("historical"), clean = c("none"), 
                                                 portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                 m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

#e-2) Eurodollar
paste("(ED1.log-returns)Expected Shortfall=",ES(alldata$ED1, p = 0.99, method = c("historical"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(ED8.log-returns)Expected Shortfall=",ES(alldata$ED8, p = 0.99, method = c("historical"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

#e-3) Equity Indices
paste("(SPX.log-returns)Expected Shortfall=",ES(alldata$SPX, p = 0.99, method = c("historical"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(RUT.log-returns)Expected Shortfall=",ES(alldata$RUT, p = 0.99, method = c("historical"), clean = c("none"), 
                                                portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(G1.log-returns)Expected Shortfall=",ES(stocks_G1_log, p = 0.99, method = c("historical"), clean = c("none"), 
                                               portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                               m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(G2.log-returns)Expected Shortfall=",ES(stocks_G2_log, p = 0.99, method = c("historical"), clean = c("none"), 
                                               portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                               m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))


#e-4) Commodity
paste("(crude_oil.log-returns)Expected Shortfall=",ES(alldata$crude_oil, p = 0.99, method = c("historical"), clean = c("none"), 
                                                      portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                      m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(natural_gas.log-returns)Expected Shortfall=",ES(alldata$natural_gas, p = 0.99, method = c("historical"), clean = c("none"), 
                                                        portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                        m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(copper.log-returns)Expected Shortfall=",ES(alldata$copper, p = 0.99, method = c("historical"), clean = c("none"), 
                                                   portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                   m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))
paste("(corn.log-returns)Expected Shortfall=",ES(alldata$corn, p = 0.99, method = c("historical"), clean = c("none"), 
                                                 portfolio_method = c("single"), weights = NULL, mu = NULL, sigma = NULL,
                                                 m3 = NULL, m4 = NULL, invert = TRUE, operational = TRUE))

















